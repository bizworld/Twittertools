<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>TwitterTools demo: ZOLTAR</title>
<style>
body {
	background-color: #000;
	font-family: arial;
	font-size: 12px;
	color: #f5f5f5;
}

a, a:visited {
	color: #FFF;
}
</style>
</head>
<body>
<img src="greatZoltar.gif" style="float:left;margin-right:10px;"/><h2>The Great Zoltar</h2>

<p>Este é um projeto de demonstração da biblioteca TwitterTools. "Zoltar" é um robô de resposta automática no Twitter, que responde os usuários com predições sobre o futuro.</p>
<p>Para testar, basta enviar uma pergunta para o perfil @GreatZoltar. Em pouco tempo ele responderá.</p>
<p>O tutorial completo e o código para download estão disponíveis aqui: <a href="http://twittertools.in/2011/07/21/novo-demo-oraculo-de-zoltar/">http://twittertools.in/2011/07/21/novo-demo-oraculo-de-zoltar/</a></p>
<br clear="all"/>

</body>
</html>
